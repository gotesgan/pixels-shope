import  mediaHandler from "../utils/mediahandle.js";

export const CreateHeroSection = async (req, res) => {
    const userid = req.user.userid;
    const storeId = req.user.storeId;
    const files = req.files;

    try {
        const userExist = await prisma.user.findUnique({
            where: {
                id: userid
            },
            include: {
                stores: {
                    select: {
                        id: true
                    }
                }
            }
        });

        const hasStoreAccess = userExist?.stores.some(store => store.id === storeId);

        if (!hasStoreAccess) {
            return res.status(400).json({
                message: "Store ID is invalid",
                success: false
            });
        }

        const uploads = await Promise.all(
            files.map(async (file) => {
                const data = await mediaHandler(file.path);
                return data.uploadedImages[0]?.filename;
            })
        );

        await Promise.all(files.map(file => fs.promises.unlink(file.path)));

        const result = await prisma.$transaction(async (tx) => {
            const heroSection = await tx.heroSection.create({
                data: {
                    storeId: storeId,
                    // example: heading: req.body.heading,
                    // other fields as needed
                }
            });

            const media = await tx.media.create({
                data: {
                    storeId: storeId,
                    heroSectionId: heroSection.id,
                    image: uploads[0]
                }
            });

            return { heroSection, media };
        });

        res.status(201).json({
            message: "Hero Section and Media Created Successfully",
            success: true,
            data: result
        });

    } catch (error) {
        console.error("Error in CreateHeroSection:", error);
        return res.status(500).json({
            message: "Something went wrong",
            success: false
        });
    }
};
