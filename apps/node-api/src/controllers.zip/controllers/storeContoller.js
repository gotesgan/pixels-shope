import prisma from "../db/db.js";

export const createStore = async (req, res) => {
  const { name, businessTypes } = req.body;
  const files = req.files || [];

  if (!name) {
    return res.status(400).json({ error: "Store name is required" });
  }

  try {
    // Format store name to generate subdomain safely
    const slug = name.toLowerCase().replace(/\s+/g, '-');
    // Using localhost IP via nip.io
    const domain = `${slug}.127.0.0.1.nip.io`;
    
    // Check if domain already exists
    const existingStore = await prisma.store.findUnique({
      where: { domain },
    });
    
    if (existingStore) {
      return res.status(400).json({ error: "Store with this name already exists on localhost" });
    }

    // Process media files if any
    let uploads = [];
    if (files.length > 0) {
      uploads = await Promise.all(
        files.map(async (file) => {
          const data = await mediaHandler(file.path);
          return data.uploadedImages[0]?.filename;
        })
      );
    }

    // Create store and related data in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create the store
      const store = await tx.store.create({
        data: {
          domain,
          userId: req.user.id, // assuming auth middleware sets req.user
        },
      });

      // Create the store info
      const storeInfo = await tx.storeInfo.create({
        data: {
          storeId: store.id,
          name,
          businessTypes: businessTypes || null,
        },
      });

      // Create media for store info if files were uploaded
      if (uploads.length > 0) {
        const media = await tx.media.create({
          data: {
            storeId: store.id,
            image: uploads[0],
            StoreInfo: {
              connect: {
                id: storeInfo.id
              }
            }
          }
        });
      }

      return { store, storeInfo };
    });

    res.status(201).json({
      message: "Store created successfully",
      store: {
        id: result.store.id,
        domain: result.store.domain,
        storeInfo: {
          name: result.storeInfo.name,
          businessTypes: result.storeInfo.businessTypes
        }
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};